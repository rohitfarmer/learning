add <- function(arg1, arg2) {
	result <- arg1 + arg2
	result
}