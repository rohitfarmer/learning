sem <- function(arg) {
	result <- sqrt(var(arg)/length(arg))
	result
}
