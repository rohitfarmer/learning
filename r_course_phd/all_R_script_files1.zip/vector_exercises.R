# vector exercises

v <- seq(0,1,0.25)
v
v <- c(0,7)
v
v <- rep(1:3,3)
v

x <- 0:10
x

y <- x^2
y

y <- sqrt(x)
y

y <- 1/x
y

y <- 1/x^2
y
