# R as calculator exercise

z <- sqrt(2) # option 1
z
z <- 2^(1/2) # option 2
z
z <- sin(2*pi)
z
z <- log(10)
z
z <- 2^10
z
z <- exp(1)^10 # option 1
z
z <- exp(10) # option 2
z
z <- 1/9
z
z <- (1/9)^2
z
z <- 27^(1/3)
z
z <- (1/9)^(1/2) # option 1
z
z <- sqrt(1/9) # option 2
z